import { createNativeCredentialStore, credentialWriteRefusedError, isCleanupUncertain, isCredentialLockError, markCleanupUncertain, replaceCredential, type CredentialStore } from "../auth/store.ts";
import type { Model } from "../model/model.ts";
import { providerDispatch, withProviderDispatch } from "../model/dispatch.ts";
import type { HostAuthRoute, HostCredentialStore, HostCredentialWriteGuard } from "./auth-routes.ts";
import { credentialReferenceForRoute } from "./auth-routes.ts";
import { HostError } from "./index.ts";

/** Shared process-local native credential ownership without credential access on the returned handle. */
export interface HostCredentialLifecycle {
  /** Fence existing route work before deleting its credential; other routes remain independent. */
  logout(route: HostAuthRoute): Promise<void>;
  /** Dispose this idle owner without logging out; active work refuses with busy. */
  close(): Promise<void>;
}

/** Optional secure-store seam for isolated deterministic embeddings; omission selects Schway's OS store. */
export interface HostCredentialLifecycleOptions { readonly store?: HostCredentialStore }

/** `renewals` counts renewals this participant sent that have not settled; `drop` is a release deferred until they have. */
type Interest = { owner: Owner; controller: AbortController; guard?: HostCredentialWriteGuard; refused: boolean; renewals: number; drop?: () => void };
type Route = { epoch: number; store: CredentialStore; interests: Set<Interest>; writes: Promise<void>; uncertain?: boolean };
type State = { base: CredentialStore; routes: Map<HostAuthRoute, Route> };
type Owner = { state: State; closed: boolean; active: number };

/** One admitted run's route authority, retained from readiness through settlement. @internal */
export interface CredentialLifecycleLease {
  readonly store: CredentialStore;
  readonly interest: Interest;
  /** Release this participant once all of its admitted work has settled. */
  release(): void;
}
const owners = new WeakMap<HostCredentialLifecycle, Owner>();
const states = new WeakMap<HostCredentialStore, State>();
let native: CredentialStore | undefined;

function ownerFor(handle: HostCredentialLifecycle): Owner {
  const owner = owners.get(handle);
  if (!owner) throw new HostError("invalid-options");
  if (owner.closed) throw new HostError("closed");
  return owner;
}

/** Fence a participant. A release it deferred for an in-flight renewal takes effect now: a refused participant authorizes nothing. */
function refuse(interest: Interest): void {
  interest.refused = true;
  const drop = interest.drop;
  interest.drop = undefined;
  drop?.();
}

function serialized<T>(route: Route, operation: () => Promise<T>): Promise<T> {
  const pending = route.writes.then(operation);
  route.writes = pending.then(() => {}, () => {});
  return pending;
}

function routeFor(state: State, name: HostAuthRoute): Route {
  let route = state.routes.get(name);
  if (!route) {
    route = { epoch: 0, store: undefined!, interests: new Set(), writes: Promise.resolve() };
    state.routes.set(name, route);
    route.store = routeStore(state, route, name);
  }
  return route;
}

function routeStore(state: State, route: Route, name: HostAuthRoute): CredentialStore {
  const epoch = route.epoch, identity = Object.freeze(credentialReferenceForRoute(name));
  const current = () => { if (epoch !== route.epoch) throw credentialWriteRefusedError(); };
  const authorize = async () => {
    current();
    const checked = new Set<Interest>(), allowed = new Set<Interest>();
    // A stopped participant still authorizes a renewal it sent until that renewal settles: the provider may already
    // have rotated the refresh token. Logout and its own guard still fence it.
    const active = (interest: Interest) => route.interests.has(interest) && !interest.refused &&
      !interest.owner.closed && (!interest.controller.signal.aborted || interest.renewals > 0);
    // Guards can yield while a sibling joins, including during that sibling's readiness.
    // Check every new participant before deciding that no authority remains.
    for (;;) {
      current();
      const pending = [...route.interests].filter(interest => !checked.has(interest));
      if (!pending.length) break;
      await Promise.all(pending.map(async interest => {
        checked.add(interest);
        if (!active(interest)) return;
        try { await interest.guard?.(identity); }
        catch { refuse(interest); return; }
        if (active(interest)) allowed.add(interest);
      }));
    }
    current();
    if (![...allowed].some(active)) throw credentialWriteRefusedError();
    // Refused peers must detach before a valid peer can use the shared renewal.
    // When all peers refuse, let the write/cleanup error reach every waiter first.
    for (const interest of route.interests) if (interest.refused) interest.controller.abort();
  };
  /** Authorize, write and re-authorize under the route chain; a refusal after a write removes exactly that value. */
  function commit(value: string, write: () => Promise<boolean>): Promise<boolean> {
    const writers = new Set([...route.interests].map(interest => interest.owner));
    for (const owner of writers) owner.active++;
    return serialized(route, async () => {
      await authorize();
      current();
      try {
        if (!await write()) return false;
        await authorize();
        return true;
      } catch (error) {
        // A credential-lock refusal means the backend write never ran: nothing to remove, and the route stays usable.
        if (isCredentialLockError(error)) throw error;
        // A backend can commit then reject. Remove only this write, under the route chain.
        try {
          if (state.base.compareAndDelete) await state.base.compareAndDelete(identity, value);
          else if (await state.base.get(identity) === value) await state.base.delete(identity);
        } catch {
          route.uncertain = true;
          const refused = credentialWriteRefusedError();
          refused.message = "Credential store write refused by the embedding-application fence. Credential cleanup could not be verified.";
          throw markCleanupUncertain(refused, new HostError("storage"));
        }
        throw error;
      }
    }).finally(() => { for (const owner of writers) owner.active--; });
  }
  return {
    async get(requested) {
      current();
      if (requested.account !== identity.account) throw new HostError("invalid-options");
      await route.writes;
      current();
      if (route.uncertain) throw new HostError("storage");
      return state.base.get(identity);
    },
    set(requested, value) {
      if (requested.account !== identity.account) return Promise.reject(new HostError("invalid-options"));
      return commit(value, async () => { await state.base.set(identity, value); return true; }).then(() => {});
    },
    // Participants' guards run first; the compare and the write then share the base store's critical section.
    compareAndSet(requested, expectedValue, value) {
      if (requested.account !== identity.account) return Promise.reject(new HostError("invalid-options"));
      return commit(value, () => replaceCredential(state.base, identity, expectedValue, value));
    },
    async delete() { throw new HostError("invalid-options"); },
  };
}

/** Create an opaque owner sharing renewal by secure-store identity and route across distinct hosts. */
export function createHostCredentialLifecycle(options: HostCredentialLifecycleOptions = {}): HostCredentialLifecycle {
  if (!options || typeof options !== "object" || Array.isArray(options) || Object.keys(options).some(key => key !== "store") ||
      (options.store !== undefined && (!options.store || typeof options.store.get !== "function" ||
        typeof options.store.set !== "function" || typeof options.store.delete !== "function"))) throw new HostError("invalid-options");
  const base = options.store ?? (native ??= createNativeCredentialStore());
  let state = states.get(base);
  if (!state) { state = { base, routes: new Map() }; states.set(base, state); }
  const owner: Owner = { state, closed: false, active: 0 };
  const handle: HostCredentialLifecycle = Object.freeze({
    async logout(name: HostAuthRoute) {
      ownerFor(handle);
      if (name !== "codex" && name !== "grok") throw new HostError("invalid-options");
      const route = routeFor(owner.state, name);
      // Rotate store identity synchronously: old provider refreshers can never write in the new epoch.
      const epoch = ++route.epoch;
      route.uncertain = true;
      route.store = routeStore(owner.state, route, name);
      for (const interest of route.interests) { refuse(interest); interest.controller.abort(); }
      owner.active++;
      try { await serialized(route, async () => {
        try { await owner.state.base.delete(credentialReferenceForRoute(name)); }
        catch { route.uncertain = true; throw new HostError("storage"); }
        // A later queued revocation must remain quarantined until its own deletion succeeds.
        if (route.epoch === epoch) route.uncertain = false;
      }); }
      catch { throw new HostError("storage"); }
      finally { owner.active--; }
    },
    async close() {
      if (owner.closed) return;
      if (owner.active) throw new HostError("busy");
      owner.closed = true;
    },
  });
  owners.set(handle, owner);
  return handle;
}

/** Validate the opaque owner without reading credentials or loading an adapter. @internal */
export function validateCredentialLifecycle(handle: HostCredentialLifecycle): void { ownerFor(handle); }

/** Register route authority before readiness and pin it through tools, retries and settlement. @internal */
export function acquireCredentialLifecycle(handle: HostCredentialLifecycle, name: HostAuthRoute, guard?: HostCredentialWriteGuard, signal?: AbortSignal): CredentialLifecycleLease {
  const owner = ownerFor(handle), route = routeFor(owner.state, name);
  const controller = new AbortController();
  const interest: Interest = { owner, controller, guard, refused: false, renewals: 0 };
  const abort = () => controller.abort();
  signal?.addEventListener("abort", abort, { once: true });
  if (signal?.aborted) abort();
  owner.active++; route.interests.add(interest);
  let released = false;
  return { store: route.store, interest, release() {
    if (released) return;
    released = true;
    signal?.removeEventListener("abort", abort);
    const drop = () => { route.interests.delete(interest); owner.active--; };
    // A renewal still in flight keeps this participant, and the owner busy, until it settles, unless it is refused.
    if (interest.renewals > 0 && !interest.refused) interest.drop = drop;
    else drop();
  } };
}

/** Resolve the current shared route store without publishing it on the lifecycle handle. @internal */
export function credentialLifecycleStore(handle: HostCredentialLifecycle, name: HostAuthRoute): CredentialStore {
  return routeFor(ownerFor(handle).state, name).store;
}

/** Keep this participant authorizing, and registered, until a renewal it sent settles, even after it stops. @internal */
export function holdRenewal(lease: CredentialLifecycleLease, settled: Promise<void>): void {
  const { interest } = lease;
  interest.renewals++;
  const settle = () => {
    if (--interest.renewals > 0 || !interest.drop) return;
    const drop = interest.drop;
    interest.drop = undefined;
    drop();
  };
  void settled.then(settle, settle);
}

/** Attach one stream's cancellation and write fence without changing its siblings' authority. @internal */
export function lifecycleModel(handle: HostCredentialLifecycle, name: HostAuthRoute, store: CredentialStore, model: Model, guard?: HostCredentialWriteGuard, admitted?: CredentialLifecycleLease): Model {
  return Object.freeze({ provider: model.provider, id: model.id, async *stream(request, call) {
    const owner = ownerFor(handle), route = routeFor(owner.state, name);
    if (route.store !== store) throw credentialWriteRefusedError();
    const lease = admitted ?? acquireCredentialLifecycle(handle, name, guard);
    const { interest } = lease, { controller } = interest;
    const abort = () => controller.abort();
    request.signal?.addEventListener("abort", abort, { once: true });
    if (request.signal?.aborted) abort();
    try {
      try { await guard?.(credentialReferenceForRoute(name)); }
      catch { interest.refused = true; throw credentialWriteRefusedError(); }
      if (interest.refused) throw credentialWriteRefusedError();
      controller.signal.throwIfAborted();
      // A renewal this stream sends outlives the stream's own stop until it settles.
      const hooks = providerDispatch(call);
      const held = hooks ? withProviderDispatch(call, { ...hooks, renewal(settled) {
        if (settled) holdRenewal(lease, settled);
        hooks.renewal(settled);
      } }) : call;
      for await (const event of model.stream({ ...request, signal: controller.signal }, held)) yield event;
    } catch (error) {
      if (isCleanupUncertain(error)) throw error;
      if (interest.refused) throw credentialWriteRefusedError();
      throw error;
    } finally {
      request.signal?.removeEventListener("abort", abort);
      if (!admitted) lease.release();
    }
  } } as Model);
}
