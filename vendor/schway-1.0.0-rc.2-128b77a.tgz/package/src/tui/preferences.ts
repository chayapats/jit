import type { ConfigEditor, ConfigScope } from "../config/editing.ts";
import { resolveThinkingSelection, describeEffectiveThinking } from "../model/thinking.ts";
import { redactSecrets } from "../auth/secrets.ts";
import { displaySetting } from "./controller-support.ts";

/** A bounded ordinary preference or an explicitly separate complete model-choice action. */
export interface PreferenceRow {
  key: string;
  label: string;
  value: string;
  effectiveValue?: string;
  origin: string;
  saved: string;
  scopeSaved?: string;
  reset: string;
  choices: readonly unknown[];
  action?: "choose-model" | "connections" | "advanced" | "basic";
}

/** Keyboard selection and preview, with no raw configuration or credential fields. */
export interface PreferencesSnapshot {
  scope: ConfigScope | "memory";
  page?: "basic" | "advanced";
  selectedIndex: number;
  choiceIndex: number;
  rows: PreferenceRow[];
  preview?: string;
  error?: string;
}

/** Describe the effect of each scope before a preference is applied. */
export const PREFERENCE_SCOPES = {
  session: "This session only · Resets on restart",
  memory: "Remember for this workspace · Configuration overrides memory",
  user: "Save for all workspaces · Project settings override",
  project: "Save for this project · Enter confirm",
} as const;

/** Build a secret-free view from the same editor used by the effective resolver. */
export function preferenceRows(editor: ConfigEditor, scope: PreferencesSnapshot["scope"], secrets: readonly string[], appearanceEnvironment?: "dark" | "light", page: "basic" | "advanced" = "basic"): PreferenceRow[] {
  const settings = editor.settings;
  const safe = (value: unknown) => redactSecrets(value === undefined ? "unset" : String(value), secrets).replace(/https?:\/\/[^\s]+/g, "[URL hidden]").replace(/[\x00-\x1f\x7f]/g, " ").slice(0, 200);
  const layers = editor.preferenceLayers;
  const labels: Record<string, string> = { memory: "workspace memory", user: "user config", project: "project config", cli: "CLI", session: "session" };
  const selection = resolveThinkingSelection({ ...settings, capability: settings.reasoningCapability });
  const context = selection.context;
  const choices: Record<string, readonly unknown[]> = {
    thinking: [undefined, ...selection.choices],
    maxTurns: [undefined, 8, 16, 32, 64, 128], maxConcurrentTools: [undefined, 1, 2, 5, 10, 20],
    contextWindow: [undefined, 8192, 32768, 65536, 131072, 200000],
    maxOutput: [undefined, 1024, 4096, 8192, 16384, 32768],
    git: [undefined, "off", "on-demand", "snapshot"],
    appearance: [undefined, "auto", "dark", "light"],
    "ui.splash": [undefined, "always", "first-run", "never"],
  };
  if (scope === "memory") return [{ key: "workspace choice", label: "Workspace choice", value: safe(`${settings.provider}/${settings.model} (${displaySetting(settings.provider === "xai" ? "xaiAuth" : "openaiAuth", settings.provider === "xai" ? settings.xaiAuth : settings.openaiAuth ?? settings.auth)})`), origin: editor.origins.model ?? "built-in default",
    saved: layers.memory?.model ? safe(`${layers.memory.provider}/${layers.memory.model} (${displaySetting(layers.memory.provider === "xai" ? "xaiAuth" : "openaiAuth", (layers.memory.provider === "xai" ? layers.memory.xaiAuth : layers.memory.openaiAuth) ?? "provider auth")}); thinking ${layers.memory.thinking ?? "default"}; profile ${layers.memory.profile ?? "none"}`) : "unset",
    reset: "Reset removes only workspace memory; explicit config and session overrides remain.", choices: ["remember active choice", "reset workspace memory"] }];
  const rows: PreferenceRow[] = ["thinking", "maxTurns", "maxConcurrentTools", "contextWindow", "maxOutput", "git", "provider", "model", "profile", "auth", "openaiAuth", "xaiAuth", "appearance", "ui.splash"].map(key => {
    const origin = safe(editor.origins[(key === "ui.splash" ? "ui" : key) as keyof typeof editor.origins] ?? "built-in default");
    const originScope = origin === "CLI" ? undefined : origin === "interactive memory" ? "memory" : origin === "user-global" ? "user" : origin === "project" ? "project" : origin === "current-session override" ? "session" : undefined;
    const memoryConflict = ["session", "cli", "project", "user"].flatMap(name => {
      const layer = layers[name], memory = layers.memory;
      if (!layer || !memory || !["model", "thinking", "profile", "provider", "openaiAuth", "xaiAuth"].includes(key)) return [];
      const conflict = ["provider", "profile", "openaiAuth", "xaiAuth"].find(field => layer[field] !== undefined && (layer[field] ?? undefined) !== memory[field]);
      return conflict ? [`${labels[name]} ${conflict} selection shadows workspace memory; reset that ${labels[name]} override to restore it.`] : [];
    })[0];
    return { key, label: PREFERENCE_LABELS[key] ?? key, value: key === "thinking" ? `${safe(settings.thinking)} (effective: ${safe(describeEffectiveThinking(settings.provider, settings.thinking, settings.model, context))})` : safe(displaySetting(key, key === "appearance" && appearanceEnvironment ? appearanceEnvironment : key === "git" ? settings.gitChangeTracking : key === "ui.splash" ? settings.splash : settings[key as keyof typeof settings])), origin: key === "appearance" && appearanceEnvironment ? "environment" : origin,
      ...(key === "thinking" ? { effectiveValue: safe(describeEffectiveThinking(settings.provider, settings.thinking, settings.model, context)) } : {}),
      scopeSaved: layers[scope]?.[key] === undefined ? "Inherited" : safe(displaySetting(key, layers[scope]?.[key])),
      saved: Object.entries(layers).filter(([, layer]) => layer[key] !== undefined).map(([name, layer]) => `${labels[name]}=${safe(displaySetting(key, layer[key]))}`).join("; ") || "No saved override",
      reset: key === "appearance" && appearanceEnvironment ? "SCHWAY_THEME overrides saved appearance. Remove it to use the saved preference; reset a scope to inherit auto." : memoryConflict ?? (origin.startsWith("profile ") ? "The selected profile supplies this value; reset its selection on the profile row or edit the named profile configuration." : origin === "CLI" ? "CLI shadows lower values: remove the launch flag to inherit." : originScope ? `Reset in ${labels[originScope]} to inherit lower values.` : "Inherited default; reset the selected scope to inherit."),
      choices: choices[key] ?? [undefined, "choose a model and connection"],
      ...(!choices[key] ? { action: "choose-model" as const } : {}) };
  });
  const action = (key: string, label: string, value: string, kind: PreferenceRow["action"]): PreferenceRow => ({ key, label, value, action: kind, choices: [label], origin: "", saved: "", reset: "" });
  if (page === "advanced") return [...rows, action("basic", "Back to basic", "", "basic")];
  const get = (key: string) => rows.find(row => row.key === key)!;
  return [
    { ...get("model"), label: "Model", value: settings.model ? safe(settings.model) : "Choose a model", choices: ["Choose model"], action: "choose-model" },
    get("thinking"),
    action("connections", "Connections", "Manage connections", "connections"),
    get("appearance"), get("git"), get("ui.splash"),
    action("advanced", "Advanced", "Limits and configuration", "advanced"),
  ];
}

/** Friendly names for editable settings, shared by rows and confirmation previews. */
export const PREFERENCE_LABELS: Record<string, string> = {
  model: "Model", thinking: "Thinking", appearance: "Appearance", git: "Track file changes", "ui.splash": "Welcome screen",
  maxTurns: "Turn limit", maxConcurrentTools: "Parallel tools", contextWindow: "Context capacity", maxOutput: "Output limit",
  provider: "Provider", profile: "Connection profile", auth: "Endpoint access", openaiAuth: "OpenAI access", xaiAuth: "Grok access",
};

/** Describe a bounded choice without exposing configuration field names. */
export function preferenceChoice(value: unknown, key = ""): string {
  if (value === undefined) return "Reset (inherit)";
  return ({ auto: "Automatic", "on-demand": "On request", snapshot: "Every turn", "first-run": "First launch", never: "Never", always: "Always" } as Record<string, string>)[String(value)] ?? displaySetting(key, value);
}
