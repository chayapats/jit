import { resolveSubscriptionRoute } from "../auth/subscription-route.ts";
import { randomBytes } from "node:crypto";
import { mkdtemp, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { runAgentLoop } from "../agent/loop.ts";
import { resolveProviderCredential } from "../auth/credentials.ts";
import { createNativeCredentialStore, type CredentialStore } from "../auth/store.ts";
import { createContextManager } from "../context/manager.ts";
import { ROUTE_FALLBACK_MODELS } from "../model/catalog.ts";
import { loadProviderModel, type FetchLike, type ProviderLoaderInput } from "../model/loader.ts";
import { isThinkingLevel, type Model, type ThinkingLevel } from "../model/model.ts";
import { createSession } from "../session/session.ts";
import { readTool, readInputSchema, type ReadInput } from "../tools/read.ts";
import { createToolRegistry } from "../tools/registry.ts";
import type { ToolDefinition } from "../tools/types.ts";
import type { Workspace } from "../workspace/workspace.ts";
import { boundedSmokeFetch, MAX_SMOKE_DISCOVERY_BYTES } from "./transport.ts";
import type { SmokeDiagnostics, SmokeProgress } from "./diagnostics.ts";
import { prepareSmokeThinking } from "./thinking.ts";

/** Independently selectable provider/auth lanes; API-key OpenAI never silently switches to subscription billing. */
export const SMOKE_PROVIDERS = ["openai-api-key", "xai-api-key", "compatible", "codex", "grok"] as const;

/** One live-smoke lane. `xai-api-key` bills the xAI console account and never reads OpenAI credentials. */
export type SmokeProvider = (typeof SMOKE_PROVIDERS)[number];
/** Explicit opt-in selection and bounded execution settings, with no implicit credential discovery. */
export interface SmokeSelection {
  enabled: boolean;
  providers: readonly SmokeProvider[];
  revision: string;
  env: Record<string, string | undefined>;
  timeoutMs: number;
  signal?: AbortSignal;
  compatible?: {
    baseUrl: string;
    auth: "required" | "none";
    profile?: string;
    credentialEnv?: string;
    credentialIdentity?: string;
  };
  models?: Partial<Record<SmokeProvider, string>>;
  /** Explicit requested reasoning levels, scoped to selected lanes; omission preserves provider defaults. */
  thinking?: Partial<Record<SmokeProvider, ThinkingLevel>>;
  /** Optional programmatic runtime key overrides, scoped to one selected provider. */
  runtimeKeys?: Partial<Record<SmokeProvider, string>>;
  /** Parent-owned workspace for an isolated subprocess; the worker must never remove it. */
  workspaceRoot?: string;
}
/** Private test seams; production defaults load only selected adapters and the native secure store. */
export interface SmokeDependencies {
  createStore?: () => CredentialStore;
  createModel?: (input: ProviderLoaderInput) => Promise<Model>;
  /** Replace HTTP with protocol fixtures inside the production cumulative byte/deadline policy. */
  fetch?: FetchLike;
  onWorkspace?: (workspace: Workspace) => void;
  /** Record that the selected model stream has started, without exposing model content. */
  onModelStarted?: () => void;
  /** Checkpoint only bounded counters and authentication category for OS-supervised timeouts. */
  onProgress?: (progress: SmokeProgress) => void;
  /** Script a bounded sentinel read in offline tests without changing the only allowed path. */
  readSentinel?: ToolDefinition<ReadInput>["execute"];
}
/** Bounded, secret-free scenario classification; no arbitrary provider messages are serialized. */
export interface SmokeScenario {
  provider: SmokeProvider;
  model: string;
  /** Explicit requested level, retained even when the lane cannot start or complete. */
  thinking?: ThinkingLevel;
  authSource: "runtime" | "env" | "stored" | "stored-subscription" | "none" | "unavailable";
  status: "passed" | "skipped" | "pending" | "failed_provider" | "failed_runner";
  reason: string;
  durationMs: number;
  toolRoundTrip: boolean;
  /** Partial progress is diagnostic evidence, never proof of a verified tool round trip or measured spend. */
  diagnostics?: SmokeDiagnostics;
  /** Deferred means an uncooperative stream still owns its temporary workspace. */
  cleanup?: "deferred";
}
/** Dated evidence tied to revision and model selections; incomplete never masquerades as pass. */
export interface SmokeReport {
  testedAt: string;
  revision: string;
  aggregate: "passed" | "incomplete" | "failed";
  scenarios: SmokeScenario[];
}

const SENTINEL_FILE = "smoke-sentinel.txt";
function sentinelReadTool(execute: ToolDefinition<ReadInput>["execute"]): ToolDefinition<ReadInput> {
  return {
    ...readTool,
    description: `Read the smoke sentinel using the exact relative path "${SENTINEL_FILE}". Do not prepend the workspace root. Output is line-numbered and bounded.`,
    inputSchema: {
      ...readInputSchema,
      properties: {
        ...readInputSchema.properties,
        path: { ...readInputSchema.properties.path, enum: [SENTINEL_FILE] },
      },
    },
    execute: async (input, context) => input.path === SENTINEL_FILE
      ? await execute(input, context)
      : { content: "Only the smoke sentinel may be read.", isError: true },
  };
}
const MAX_OUTPUT_CHARS = 4096;
const SETTLEMENT_GRACE_MS = 40;
const MAX_TURNS = 2;
const MAX_TOKENS = 256;
const SAFE_ID = /^[a-zA-Z0-9._:/-]{1,100}$/;
const DEFAULT_MODELS: Record<SmokeProvider, string> = {
  "openai-api-key": ROUTE_FALLBACK_MODELS.openai,
  "xai-api-key": ROUTE_FALLBACK_MODELS.xai,
  compatible: ROUTE_FALLBACK_MODELS["openai-compatible"],
  codex: ROUTE_FALLBACK_MODELS.openai,
  grok: ROUTE_FALLBACK_MODELS.xai,
};

/** Execute only explicitly enabled lanes through Schway's real streaming loop and isolated read tool. */
export async function runLiveSmoke(selection: SmokeSelection, deps: SmokeDependencies = {}): Promise<SmokeReport> {
  const scenarios: SmokeScenario[] = [];
  let priorUnsettled = false;
  for (const provider of [...new Set(selection.providers)]) {
    const start = performance.now();
    const requestedModel = selection.models?.[provider] ?? DEFAULT_MODELS[provider];
    const scenario: SmokeScenario = {
      provider, model: SAFE_ID.test(requestedModel) ? requestedModel : "invalid-model-id",
      ...(isThinkingLevel(selection.thinking?.[provider]) ? { thinking: selection.thinking![provider] } : {}),
      authSource: "unavailable", status: "skipped", reason: "live_disabled", durationMs: 0, toolRoundTrip: false,
    };
    if (priorUnsettled) { scenario.status = "pending"; scenario.reason = "prior_run_unsettled"; }
    else if (selection.enabled) await runScenario(selection, provider, scenario, deps);
    scenario.durationMs = Math.round(performance.now() - start);
    scenarios.push(scenario);
    if (scenario.cleanup === "deferred") priorUnsettled = true;
  }
  const aggregate = scenarios.some(s => s.status === "failed_provider" || s.status === "failed_runner") ? "failed"
    : scenarios.length > 0 && scenarios.every(s => s.status === "passed") ? "passed" : "incomplete";
  return { testedAt: new Date().toISOString(), revision: SAFE_ID.test(selection.revision) ? selection.revision : "unknown", aggregate, scenarios };
}

/** Bound the entire selected lane and always drain the cooperative loop before removing its workspace. */
async function runScenario(selection: SmokeSelection, provider: SmokeProvider, result: SmokeScenario, deps: SmokeDependencies): Promise<void> {
  if (selection.signal?.aborted) { result.status = "pending"; result.reason = "cancelled"; return; }
  if (!SAFE_ID.test(result.model) || !Number.isInteger(selection.timeoutMs) || selection.timeoutMs < 1 || selection.timeoutMs > 120_000
    || (selection.thinking?.[provider] !== undefined && !isThinkingLevel(selection.thinking[provider]))) {
    result.status = "failed_runner"; result.reason = "invalid_settings"; return;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), selection.timeoutMs);
  const signal = selection.signal ? AbortSignal.any([controller.signal, selection.signal]) : controller.signal;
  let directory: string | undefined;
  let startedModel = false;
  let stream: Promise<void> | undefined;
  let unsettled = false;
  let outputLimit = false;
  let disallowedTool = false;
  const diagnostics: SmokeDiagnostics = { modelAttemptsStarted: 0, modelRoundsCompleted: 0, toolResultsCompleted: 0,
    providerRetries: 0, httpRequestsStarted: 0, httpResponsesReceived: 0 };
  result.diagnostics = diagnostics;
  let checkpointsActive = true;
  const checkpoint = () => {
    if (checkpointsActive) deps.onProgress?.({ authSource: result.authSource, diagnostics: { ...diagnostics } });
  };
  try {
    // OS keychain reads are not cancellable; do not allow a late resolution
    // to mutate an already-published timeout report.
    const resolved: SmokeScenario = { ...result };
    const input = await awaitSetup(resolveInput(selection, provider, resolved, deps), signal);
    if (!signal.aborted) Object.assign(result, resolved);
    checkpoint();
    if (!input || signal.aborted) {
      if (signal.aborted) { result.status = selection.signal?.aborted ? "pending" : "failed_runner"; result.reason = selection.signal?.aborted ? "cancelled" : "timeout"; }
      return;
    }
    // Bound selected production adapters' SSE response bytes before their parsers
    // can accumulate streamed arguments without emitting normalized model events.
    const transportOptions = { signal, fetch: deps.fetch, onLimit: () => { outputLimit = true; controller.abort(); },
      onProgress: (event: { type: "request" } | { type: "response"; status: number }) => {
        if (event.type === "request") diagnostics.httpRequestsStarted++;
        else { diagnostics.httpResponsesReceived++; diagnostics.lastHttpStatus = event.status; }
        checkpoint();
      } };
    const fetchFn = boundedSmokeFetch(transportOptions);
    // Catalog metadata must not consume the two inference rounds' cumulative SSE budget.
    const discoveryFetch = boundedSmokeFetch({ ...transportOptions, maxBytes: MAX_SMOKE_DISCOVERY_BYTES });
    input.thinking = result.thinking;
    const thinkingError = await awaitSetup(prepareSmokeThinking(input, discoveryFetch, signal), signal);
    if (signal.aborted) throw Error("setup aborted");
    if (thinkingError) { result.status = "failed_runner"; result.reason = thinkingError; return; }
    const model = await awaitSetup((deps.createModel ?? (input => loadProviderModel(input, fetchFn)))(input), signal);
    result.model = SAFE_ID.test(model.id) ? model.id : "invalid-model-id";
    // The loop registers activate_skill whenever it has a workspace. Do not
    // advertise that unrelated tool to the selected smoke transport. The
    // conversation's prompt-cache key passes through, as in production.
    const smokeModel: Model = {
      provider: model.provider, id: model.id,
      stream: (request, call) => model.stream({ ...request, tools: request.tools?.filter(tool => tool.name === "read") }, call),
    };
    directory = selection.workspaceRoot ?? await mkdtemp(join(tmpdir(), "schway-live-"));
    // Never promote an ancestor Git root if TMPDIR happens to live inside a repository.
    const root = await realpath(directory);
    const workspace: Workspace = { root, launchCwd: root, extraRoots: [] };
    deps.onWorkspace?.(workspace);
    const marker = randomBytes(20).toString("hex");
    await writeFile(join(directory, SENTINEL_FILE), `${marker}\n`, { flag: "wx", mode: 0o600 });
    const session = createSession([{
      type: "user", id: crypto.randomUUID(), content: [{ type: "text", text:
        `Use the read tool with path exactly "${SENTINEL_FILE}" (a relative path; do not prepend the workspace root) to read the first line. Then reply with only the exact value on its first line. Do not guess.` }],
    }]);
    let error = false;
    let needsLogin = false;
    let finished: string | undefined;
    let chars = 0;
    stream = (async () => {
      for await (const event of runAgentLoop({ session, model: smokeModel, workspace, contextManager: createContextManager(workspace),
        tools: createToolRegistry([sentinelReadTool(deps.readSentinel ?? readTool.execute)]), signal, maxTurns: MAX_TURNS })) {
        if (event.type === "model.started") {
          startedModel = true; diagnostics.modelAttemptsStarted++; checkpoint(); deps.onModelStarted?.();
        }
        if (event.type === "model.retry") { diagnostics.providerRetries++; checkpoint(); }
        if (event.type === "model.delta") chars += event.content.text.length;
        // A completed model message is yielded before the loop schedules its tool calls.
        // This caps assembled arguments at the runner seam, not provider wire bytes.
        if (event.type === "model.finished") {
          diagnostics.modelRoundsCompleted++; checkpoint();
          const last = session.items.at(-1);
          if (last?.type === "assistant") {
            chars += JSON.stringify(last).length;
            // The loop yields before scheduling tools: reject an unadvertised call here,
            // before its automatic activate_skill registration can execute anything.
            if (last.content.some(block => block.type === "tool_call" && block.name !== "read")) disallowedTool = true;
          }
        }
        if (event.type === "tool.finished") { chars += event.content.length; diagnostics.toolResultsCompleted++; checkpoint(); }
        if (chars > MAX_OUTPUT_CHARS) { outputLimit = true; controller.abort(); break; }
        if (disallowedTool) { controller.abort(); break; }
        if (event.type === "error") {
          error = true;
          needsLogin = (provider === "codex" || provider === "grok") && /Sign in again in interactive mode|subscription session (expired|was revoked)/i.test(event.message);
        }
        if (event.type === "agent.finished") finished = event.reason;
      }
    })();
    // Abort bounds the report even if an adapter ignores it. Never remove the workspace
    // before the still-running stream and any accepted tool I/O have actually settled.
    await awaitSetup(stream, signal);
    if (selection.signal?.aborted) { result.status = "pending"; result.reason = "cancelled"; return; }
    if (outputLimit) { result.status = "failed_provider"; result.reason = "output_limit"; return; }
    if (controller.signal.aborted) { result.status = startedModel ? "failed_provider" : "failed_runner"; result.reason = "timeout"; return; }
    if (error || finished === "error") {
      result.status = needsLogin ? "pending" : startedModel ? "failed_provider" : "failed_runner";
      result.reason = needsLogin ? "subscription_requires_login" : startedModel ? "provider_error" : "runner_error";
      return;
    }
    if (finished !== "completed") { result.status = "failed_provider"; result.reason = finished === "max_turns" ? "turn_limit" : "no_final_response"; return; }
    const calls = session.items.filter(item => item.type === "assistant").flatMap(item => item.type === "assistant" ? item.content.filter(block => block.type === "tool_call") : []);
    const results = session.items.filter(item => item.type === "tool_result");
    const final = session.items.at(-1);
    result.toolRoundTrip = calls.length === 1 && calls[0]?.type === "tool_call" && calls[0].name === "read"
      && typeof calls[0].arguments === "object" && calls[0].arguments !== null
      && (calls[0].arguments as { path?: unknown }).path === SENTINEL_FILE
      && results.length === 1 && results[0]?.type === "tool_result" && results[0].toolCallId === calls[0].id
      && !results[0].isError && results[0].content.includes(marker);
    const answer = final?.type === "assistant" ? final.content.filter(block => block.type === "text").map(block => block.text).join("") : "";
    result.status = result.toolRoundTrip && answer === marker ? "passed" : "failed_provider";
    result.reason = result.status === "passed" ? "verified" : "missing_tool_evidence";
  } catch {
    if (stream && signal.aborted) {
      // Cooperative adapters get a short, bounded chance to finish cancellation.
      // A non-cooperative adapter cannot block the report or authorize deleting its workspace.
      const settled = await Promise.race([
        stream.then(() => true, () => true),
        Bun.sleep(SETTLEMENT_GRACE_MS).then(() => false),
      ]);
      unsettled = !settled;
    }
    result.status = selection.signal?.aborted ? "pending" : (outputLimit || disallowedTool || controller.signal.aborted && startedModel) ? "failed_provider" : "failed_runner";
    result.reason = selection.signal?.aborted ? "cancelled" : outputLimit ? "output_limit" : disallowedTool ? "disallowed_tool"
      : controller.signal.aborted ? (unsettled ? "timeout_unsettled" : "timeout") : "runner_error";
  } finally {
    // A non-cooperative stream may continue after publication; freeze its report and stop writing checkpoints.
    checkpointsActive = false;
    result.diagnostics = { ...diagnostics };
    clearTimeout(timer);
    if (directory && !selection.workspaceRoot) {
      if (unsettled && stream) {
        result.cleanup = "deferred";
        const retained = directory;
        // Keep the workspace if the stream never settles; a settled stream releases it.
        void stream.then(() => rm(retained, { recursive: true, force: true }),
          () => rm(retained, { recursive: true, force: true })).catch(() => {});
      } else {
        try { await rm(directory, { recursive: true, force: true }); }
        catch { result.status = "failed_runner"; result.reason = "cleanup_failed"; }
      }
    }
  }
}

/** Resolve auth only for the selected lane, without an interactive flow or billing fallback. */
async function resolveInput(selection: SmokeSelection, provider: SmokeProvider, result: SmokeScenario, deps: SmokeDependencies): Promise<ProviderLoaderInput | undefined> {
  const model = result.model;
  if (provider === "compatible" && (!selection.compatible || !isSafeEndpoint(selection.compatible.baseUrl))) {
    result.status = "pending"; result.reason = "compatible_endpoint_required"; return;
  }
  // Reject before even constructing the OS store: no credential may travel over HTTP.
  if (provider === "compatible" && !isSafeSmokeEndpoint(selection.compatible!.baseUrl, selection.compatible!.auth)) {
    result.status = "failed_runner"; result.reason = "insecure_endpoint"; return;
  }
  const store = provider === "compatible" && selection.compatible?.auth === "none"
    ? undefined : (deps.createStore ?? createNativeCredentialStore)();
  if (provider === "codex" || provider === "grok") {
    const resolved = await resolveSubscriptionRoute({ provider, model, maxTokens: MAX_TOKENS, store: store!, env: selection.env });
    if ("reason" in resolved) { result.status = "pending"; result.reason = resolved.reason; return; }
    result.authSource = "stored-subscription";
    return resolved.input;
  }
  const family = provider === "compatible" ? "openai-compatible" : provider === "xai-api-key" ? "xai" : "openai";
  const credential = await resolveProviderCredential({
    provider: family, baseUrl: selection.compatible?.baseUrl, auth: selection.compatible?.auth,
    profile: selection.compatible?.profile, credentialEnv: selection.compatible?.credentialEnv,
    credentialIdentity: selection.compatible?.credentialIdentity,
    runtimeApiKey: provider === "compatible" && selection.compatible?.auth === "none" ? undefined : selection.runtimeKeys?.[provider], env: selection.env,
    store: store ?? { get: async () => null, set: async () => {}, delete: async () => false },
  });
  if ("error" in credential) {
    result.status = "skipped";
    result.reason = credential.error.startsWith("Cannot read credential") ? "credential_store_unavailable" : "missing_credentials";
    return;
  }
  result.authSource = credential.source;
  return { provider: family, apiKey: credential.apiKey, model, maxTokens: MAX_TOKENS,
    ...(family === "openai" ? { openaiAuth: "api-key" as const } : {}),
    ...(family === "openai-compatible" ? { baseUrl: selection.compatible!.baseUrl, auth: selection.compatible!.auth } : {}),
  };
}

/** Stop waiting for non-cancellable setup (such as an OS keychain read) before any model stream begins. */
async function awaitSetup<T>(operation: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) { void operation.catch(() => {}); throw new Error("setup aborted"); }
  return new Promise<T>((resolve, reject) => {
    const abort = () => reject(new Error("setup aborted"));
    signal.addEventListener("abort", abort, { once: true });
    void operation.then(
      value => { signal.removeEventListener("abort", abort); resolve(value); },
      error => { signal.removeEventListener("abort", abort); reject(error); },
    );
  });
}

/** Permit TLS smoke endpoints or explicit no-auth local HTTP; reject all credentialed plaintext connections. */
export function isSafeSmokeEndpoint(value: string, auth: "required" | "none"): boolean {
  if (!isSafeEndpoint(value)) return false;
  const url = new URL(value);
  return url.protocol === "https:" || auth === "none" && url.protocol === "http:"
    && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname.toLowerCase());
}

/** Accept only HTTP(S) compatible endpoints without URL-embedded secrets or fragments. */
export function isSafeEndpoint(value: string): boolean {
  try {
    const url = new URL(value);
    return /^https?:$/.test(url.protocol) && !url.username && !url.password && !url.search && !url.hash;
  } catch { return false; }
}
